const { contextBridge, ipcRenderer } = require("electron");

// Ana süreç (main) ile arayüz (renderer) arasında güvenli bir köprü oluşturur.
// "window.api" üzerinden arayüzde bu fonksiyonlara erişilebilir.
contextBridge.exposeInMainWorld("api", {
  // Giriş yapma fonksiyonu, ana süreçteki "login" kanalını tetikler
  login: (data) => ipcRenderer.invoke("login", data),

  // Araç işlemlerini tetikleyen fonksiyonlar
  getCars: () => ipcRenderer.invoke("getCars"), // Otoparktaki araçları getirir
  addCar: (car) => ipcRenderer.invoke("addCar", car), // Yeni araç ekler
  exitCar: (id) => ipcRenderer.invoke("exitCar", id), // Araç çıkış işlemini yapar

  // Çıkış yapmış araçların (geçmişin) listesini getirir
  getLogs: () => ipcRenderer.invoke("getLogs"),

  // Personel yönetim işlemlerini tetikleyen fonksiyonlar
  addUser: (user) => ipcRenderer.invoke("addUser", user), // Yeni personel ekler
  getUsers: () => ipcRenderer.invoke("getUsers"), // Personel listesini getirir
  deleteUser: (id) => ipcRenderer.invoke("deleteUser", id), // Personel siler
  updateUser: (user) => ipcRenderer.invoke("updateUser", user), // Personel bilgisini günceller

  // Mobil Cihaz Bağlantısı için
  getServerAddress: () => ipcRenderer.invoke("getServerAddress"),
  onMobileImageReceived: (callback) => ipcRenderer.on("mobile-image-received", (event, base64) => callback(base64))
});