INSERT INTO Users (Username, Password, Role)
VALUES ('admin', '1234', 'admin');
SELECT * FROM Users;
INSERT INTO Users (Username, Password, Role)
VALUES ('personel', '1234', 'staff');