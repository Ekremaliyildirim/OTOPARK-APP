const { app, BrowserWindow, ipcMain } = require("electron");
const path = require("path");
const http = require("http");
const os = require("os");
const db = require("./db"); // Veritabanı bağlantı dosyasını içeri aktarıyoruz

let win;

// SQL Injection saldırılarını önlemek için tek tırnakları çift tırnağa dönüştüren yardımcı fonksiyon
function escapeSql(value) {
  return String(value ?? "").replace(/'/g, "''");
}

// Uygulama penceresini oluşturan fonksiyon
function createWindow() {
  win = new BrowserWindow({
    width: 1250,
    height: 850,
    webPreferences: {
      // Preload betiği, renderer (arayüz) ile main (ana süreç) arasındaki iletişimi güvenli kurar
      preload: path.join(__dirname, "preload.js")
    }
  });

  // İlk açılışta login.html sayfasını yüklüyoruz
  win.loadFile(path.join(__dirname, "renderer/login.html"));
}

// Electron hazır olduğunda pencereyi oluştur
app.whenReady().then(createWindow);

// Tüm pencereler kapatıldığında uygulamadan çık (macOS hariç)
app.on("window-all-closed", () => {
  if (process.platform !== "darwin") app.quit();
});

// ==================================
// MOBİL KAMERA İÇİN YEREL SUNUCU (HTTP)
// ==================================
function getLocalIP() {
  const interfaces = os.networkInterfaces();
  for (const name of Object.keys(interfaces)) {
    for (const iface of interfaces[name]) {
      if (iface.family === 'IPv4' && !iface.internal) {
        return iface.address;
      }
    }
  }
  return '127.0.0.1';
}

const localIP = getLocalIP();
const PORT = 3000;

const mobileServer = http.createServer((req, res) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST');

  if (req.method === 'GET' && req.url === '/') {
    res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
    res.end(`
      <!DOCTYPE html>
      <html lang="tr">
      <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
        <title>Otopark Plaka Tarayıcı</title>
        <style>
          body { font-family: sans-serif; background: #0f172a; color: white; display: flex; flex-direction: column; align-items: center; justify-content: center; height: 100vh; margin: 0; }
          .btn { background: #3b82f6; color: white; border: none; padding: 20px 40px; font-size: 24px; border-radius: 16px; margin-top: 20px; width: 80%; text-align: center; }
          .btn:active { background: #2563eb; }
          #status { margin-top: 20px; color: #94a3b8; font-size: 18px; text-align:center; padding: 0 20px; }
        </style>
      </head>
      <body>
        <h1 style="margin: 0; font-size: 28px;">📷 Plaka Tarayıcı</h1>
        <p style="color: #cbd5e1; text-align: center; margin-top:10px;">Plaka fotoğrafı çekin.<br>Otomatik olarak bilgisayara aktarılacaktır.</p>
        
        <input type="file" id="cameraInput" accept="image/*" capture="environment" style="display: none;">
        <button class="btn" onclick="document.getElementById('cameraInput').click()">Fotoğraf Çek</button>
        
        <div id="status"></div>

        <script>
          const input = document.getElementById('cameraInput');
          const status = document.getElementById('status');

          input.addEventListener('change', (e) => {
            const file = e.target.files[0];
            if (!file) return;

            status.innerHTML = "Fotoğraf işleniyor... ⏳";
            
            const img = new Image();
            img.onload = () => {
              const canvas = document.createElement('canvas');
              let width = img.width;
              let height = img.height;
              const max_size = 1200; // Çözünürlüğü küçülterek hız ve bellek optimizasyonu yapıyoruz
              
              if (width > height) {
                if (width > max_size) {
                  height *= max_size / width;
                  width = max_size;
                }
              } else {
                if (height > max_size) {
                  width *= max_size / height;
                  height = max_size;
                }
              }
              canvas.width = width;
              canvas.height = height;
              const ctx = canvas.getContext('2d');
              ctx.drawImage(img, 0, 0, width, height);
              
              // Jpeg olarak %80 kalite ile küçültüp Base64 formatına çeviriyoruz
              const base64 = canvas.toDataURL('image/jpeg', 0.8);
              
              status.innerHTML = "Bilgisayara aktarılıyor... ⏳";

              fetch('/upload', {
                method: 'POST',
                body: base64
              })
              .then(response => {
                if(response.ok) {
                  status.innerHTML = "<span style='color: #22c55e;'>✅ Gönderildi! Bilgisayar ekranına bakın.</span>";
                  setTimeout(() => status.innerHTML = "", 4000);
                } else {
                  status.innerHTML = "<span style='color: #ef4444;'>❌ Gönderme hatası.</span>";
                }
              })
              .catch(err => {
                status.innerHTML = "<span style='color: #ef4444;'>❌ Bağlantı hatası.</span>";
              });
            };
            
            const reader = new FileReader();
            reader.onload = (e) => { img.src = e.target.result; };
            reader.readAsDataURL(file);
          });
        </script>
      </body>
      </html>
    `);
  } else if (req.method === 'POST' && req.url === '/upload') {
    let body = '';
    req.on('data', chunk => { body += chunk.toString(); });
    req.on('end', () => {
      if (win) {
        win.webContents.send('mobile-image-received', body);
      }
      res.writeHead(200);
      res.end('OK');
    });
  } else {
    res.writeHead(404);
    res.end('Not Found');
  }
});

mobileServer.listen(PORT, '0.0.0.0', () => {
  console.log('Mobile server is running on http://' + localIP + ':' + PORT);
});

ipcMain.handle('getServerAddress', () => {
  return 'http://' + localIP + ':' + PORT;
});

// ==================================
// LOGIN (GİRİŞ İŞLEMLERİ)
// ==================================

// Kullanıcının (admin veya personel) giriş yapmasını kontrol eder
ipcMain.handle("login", async (event, data) => {
  const username = escapeSql(data.username);
  const password = escapeSql(data.password);

  const result = await db.query(`
    SELECT TOP 1 Id, Username, Password, Role
    FROM Users
    WHERE Username='${username}' AND Password='${password}'
  `);

  return result[0] || null; // Kullanıcı varsa ilk kaydı döndür, yoksa null
});

// ====================================
// ARAÇ İŞLEMLERİ
// ====================================

// İçerideki (çıkış yapmamış) araçların listesini getirir
ipcMain.handle("getCars", async () => {
  return await db.query(`
    SELECT Id, Plate, Brand, Model, Owner, Park, EntryTime, ExitTime, Fee
    FROM Cars
    WHERE ExitTime IS NULL
    ORDER BY EntryTime DESC
  `);
});

// Yeni araç kaydı oluşturur
ipcMain.handle("addCar", async (event, car) => {
  const plate = escapeSql(car.plate);
  const brand = escapeSql(car.brand);
  const model = escapeSql(car.model);
  const owner = escapeSql(car.owner);
  const park = escapeSql(car.park);

  await db.query(`
    INSERT INTO Cars (Plate, Brand, Model, Owner, Park)
    VALUES ('${plate}', '${brand}', '${model}', '${owner}', '${park}')
  `);

  return { ok: true };
});

// Araç çıkış işlemini yapar ve ücreti hesaplar
ipcMain.handle("exitCar", async (event, id) => {
  const carId = Number(id);

  // Önce aracın giriş zamanını bul
  const cars = await db.query(`
    SELECT TOP 1 Id, EntryTime
    FROM Cars
    WHERE Id=${carId}
  `);

  if (cars.length === 0) {
    return { ok: false, error: "Araç bulunamadı." };
  }

  const entry = new Date(cars[0].EntryTime);
  const now = new Date();

  // Kaldığı süreyi saat bazında yukarı yuvarlayarak hesapla
  const hours = Math.max(1, Math.ceil((now - entry) / (1000 * 60 * 60)));
  const fee = hours * 50; // Saati 50 TL olarak ücretlendir

  // Çıkış saatini ve ücreti veritabanına kaydet
  await db.query(`
    UPDATE Cars
    SET ExitTime=GETDATE(), Fee=${fee}
    WHERE Id=${carId}
  `);

  return { ok: true, hours, fee };
});

// Çıkış yapmış araçların listesini (logları) getirir
ipcMain.handle("getLogs", async () => {
  return await db.query(`
    SELECT Id, Plate, Brand, Model, Owner, Park, EntryTime, ExitTime, Fee
    FROM Cars
    WHERE ExitTime IS NOT NULL
    ORDER BY ExitTime DESC
  `);
});

// ====================================
// PERSONEL İŞLEMLERİ (SADECE ADMIN)
// =========================

// Yeni personel ekler
ipcMain.handle("addUser", async (event, user) => {
  const username = escapeSql(user.username);
  const password = escapeSql(user.password);

  if (!username || !password) {
    return { ok: false, error: "Kullanıcı adı ve şifre boş olamaz." };
  }

  // Kullanıcı adının benzersiz (unique) olup olmadığını kontrol et
  const exists = await db.query(`
    SELECT TOP 1 Id
    FROM Users
    WHERE Username='${username}'
  `);

  if (exists.length > 0) {
    return { ok: false, error: "Bu kullanıcı adı zaten kullanılıyor." };
  }

  // Yeni personeli kaydet
  await db.query(`
    INSERT INTO Users (Username, Password, Role)
    VALUES ('${username}', '${password}', 'staff')
  `);

  return { ok: true };
});

// Sadece 'staff' (personel) rolündeki kullanıcıları getirir
ipcMain.handle("getUsers", async () => {
  return await db.query(`
    SELECT Id, Username, Password, Role
    FROM Users
    WHERE Role='staff'
    ORDER BY Id DESC
  `);
});

// Personel siler
ipcMain.handle("deleteUser", async (event, id) => {
  const userId = Number(id);

  await db.query(`
    DELETE FROM Users
    WHERE Id=${userId} AND Role='staff'
  `);

  return { ok: true };
});

// Personel bilgilerini günceller
ipcMain.handle("updateUser", async (event, user) => {
  const id = Number(user.id);
  const username = escapeSql(user.username);
  const password = escapeSql(user.password);

  if (!username || !password) {
    return { ok: false, error: "Kullanıcı adı ve şifre boş olamaz." };
  }

  // Güncellenecek kullanıcı adının başka bir personele ait olup olmadığını kontrol et
  const exists = await db.query(`
    SELECT TOP 1 Id
    FROM Users
    WHERE Username='${username}' AND Id<>${id}
  `);

  if (exists.length > 0) {
    return { ok: false, error: "Bu kullanıcı adı başka bir personelde kullanılıyor." };
  }

  // Bilgileri güncelle
  await db.query(`
    UPDATE Users
    SET Username='${username}', Password='${password}'
    WHERE Id=${id} AND Role='staff'
  `);

  return { ok: true };
});