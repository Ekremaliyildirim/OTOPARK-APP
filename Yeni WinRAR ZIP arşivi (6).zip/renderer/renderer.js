// Otoparkın maksimum kapasitesi
const MAX_CAPACITY = 20;

// Park yerlerinin isimlerini oluşturur (A1, A2... A20)
const PARK_SLOTS = Array.from({ length: 20 }, (_, i) => "A" + (i + 1));

let activeCarsCache = [];

// Gelir tablosu (chart.js) instance'ını tutar
let incomeChartInstance = null;

// Ekrandaki personellerin listesini önbellekte tutar
let staffUsers = [];

// Oturum açan kullanıcının rolü ('admin' veya 'staff')
const role = localStorage.getItem("role");

/* =========================
   SAYFA GEÇİŞ (Menü navigasyonu)
========================= */

// Dashboard ve Araçlar sayfaları arasında geçişi sağlar
function showPage(page) {
  const dashboardPage = document.getElementById("dashboardPage");
  const carsPage = document.getElementById("carsPage");
  const dashboardBtn = document.getElementById("dashboardBtn");
  const carsBtn = document.getElementById("carsBtn");

  if (dashboardPage) dashboardPage.classList.add("hidden");
  if (carsPage) carsPage.classList.add("hidden");

  if (dashboardBtn) dashboardBtn.classList.remove("active");
  if (carsBtn) carsBtn.classList.remove("active");

  if (page === "dashboard") {
    if (dashboardPage) dashboardPage.classList.remove("hidden");
    if (dashboardBtn) dashboardBtn.classList.add("active");
  }

  if (page === "cars") {
    if (carsPage) carsPage.classList.remove("hidden");
    if (carsBtn) carsBtn.classList.add("active");
  }

  load();
}

// Oturumu kapatıp login sayfasına döner
async function logout() {
  const result = await Swal.fire({
    title: "Çıkış",
    text: "Çıkış yapmak istediğinizden emin misiniz?",
    icon: "question",
    showCancelButton: true,
    confirmButtonColor: "#d33",
    cancelButtonColor: "#3085d6",
    confirmButtonText: "Evet, çıkış yap",
    cancelButtonText: "İptal"
  });

  if (result.isConfirmed) {
    localStorage.clear();
    window.location.href = "login.html";
  }
}

/* =========================
   PARK SELECT (Dropdown doldurma)
========================= */

// Araç ekleme formundaki park yeri seçme kutusunu doldurur
function loadParkOptions() {
  const parkSelect = document.getElementById("park");

  if (!parkSelect) return;

  parkSelect.innerHTML = `<option value="">Park Yeri Seç</option>`;

  PARK_SLOTS.forEach(slot => {
    const option = document.createElement("option");
    option.value = slot;
    option.textContent = slot;
    parkSelect.appendChild(option);
  });
}

/* =========================
   VERİLERİ YÜKLE
========================= */

// Sayfadaki tüm verileri güncelleyen ana fonksiyon
async function load() {
  const cars = await window.api.getCars();

  activeCarsCache = cars;

  updateAdminDashboard(cars);
  updateStaffDashboard(cars);
  renderParkingGrid(cars);
  filterCarTable();
  updateParkSelectAvailability(cars);

  if (role === "admin") {
    await loadAdminExtraData();
  }
}

/* =========================
   ADMIN DASHBOARD (Admin Özel İşlemler)
========================= */

// Admin için üst kısımdaki toplam, boş alan ve doluluk oranını hesaplar
function updateAdminDashboard(cars) {
  const total = cars.length;
  const empty = MAX_CAPACITY - total;
  const percent = Math.floor((total / MAX_CAPACITY) * 100);

  const totalCars = document.getElementById("totalCars");
  const emptySlots = document.getElementById("emptySlots");
  const occupancy = document.getElementById("occupancy");

  if (totalCars) totalCars.innerText = total;
  if (emptySlots) emptySlots.innerText = empty;
  if (occupancy) occupancy.innerText = "%" + percent;
}

// Admin ekranı için log (geçmiş) ve kullanıcı (personel) verilerini getirir
async function loadAdminExtraData() {
  const logs = await window.api.getLogs();
  const users = await window.api.getUsers();

  staffUsers = users;

  updateIncome(logs);
  renderLogs(logs);
  renderUsers(users);

  const staffCount = document.getElementById("staffCount");
  if (staffCount) staffCount.innerText = users.length;
}

// Çıkış yapmış araçların ücretlerine bakarak günlük, haftalık, aylık geliri hesaplar
function updateIncome(logs) {
  let daily = 0;
  let weekly = 0;
  let monthly = 0;

  const now = new Date();

  logs.forEach(log => {
    const fee = Number(log.Fee) || 0;
    const exitDate = parseDateSafe(log.ExitTime);

    if (!exitDate) return;

    const diffDays = (now - exitDate) / (1000 * 60 * 60 * 24);

    if (diffDays <= 1) daily += fee;
    if (diffDays <= 7) weekly += fee;
    if (diffDays <= 30) monthly += fee;
  });

  const dailyIncome = document.getElementById("dailyIncome");
  const weeklyIncome = document.getElementById("weeklyIncome");
  const monthlyIncome = document.getElementById("monthlyIncome");

  if (dailyIncome) dailyIncome.innerText = daily + " TL";
  if (weeklyIncome) weeklyIncome.innerText = weekly + " TL";
  if (monthlyIncome) monthlyIncome.innerText = monthly + " TL";

  renderIncomeChart(daily, weekly, monthly);
}

// Chart.js kullanarak bar grafiğini çizer
function renderIncomeChart(daily, weekly, monthly) {
  const ctx = document.getElementById("incomeChart");
  if (!ctx) return;

  if (incomeChartInstance) {
    incomeChartInstance.destroy();
  }

  incomeChartInstance = new Chart(ctx, {
    type: "bar",
    data: {
      labels: ["Günlük", "Haftalık", "Aylık"],
      datasets: [{
        label: "Gelir",
        data: [daily, weekly, monthly],
        backgroundColor: ["#22c55e", "#3b82f6", "#f59e0b"],
        borderRadius: 10
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: {
          labels: {
            color: "#cbd5e1"
          }
        }
      },
      scales: {
        x: {
          ticks: {
            color: "#cbd5e1"
          },
          grid: {
            color: "rgba(148,163,184,0.08)"
          }
        },
        y: {
          beginAtZero: true,
          ticks: {
            color: "#cbd5e1"
          },
          grid: {
            color: "rgba(148,163,184,0.08)"
          }
        }
      }
    }
  });
}

// Geçmiş araç çıkışlarının loglarını ekrana listeler
function renderLogs(logs) {
  const logList = document.getElementById("logList");
  if (!logList) return;

  logList.innerHTML = "";

  if (logs.length === 0) {
    logList.innerHTML = `<div class="empty-text">Henüz çıkış yapılmış araç yok.</div>`;
    return;
  }

  logs.forEach(log => {
    logList.innerHTML += `
      <div class="log-item">
        <div>
          <strong>${log.Plate || "-"}</strong>
          <span>Park: ${log.Park || "-"}</span>
        </div>

        <div>
          <span>Giriş: ${formatDate(log.EntryTime)}</span>
          <span>Çıkış: ${formatDate(log.ExitTime)}</span>
        </div>

        <strong>${Number(log.Fee) || 0} TL</strong>
      </div>
    `;
  });
}

/* =========================
   PERSONEL YÖNETİMİ
========================= */

// Admin sayfasındaki personel listesini çizer
function renderUsers(users) {
  const userList = document.getElementById("userList");
  if (!userList) return;

  userList.innerHTML = "";

  if (users.length === 0) {
    userList.innerHTML = `<div class="empty-text">Henüz personel eklenmemiş.</div>`;
    return;
  }

  users.forEach(user => {
    userList.innerHTML += `
      <div class="staff-item">
        <div>
          <strong>${user.Username}</strong>
          <span>Şifre: ${user.Password}</span>
        </div>

        <div class="staff-actions">
          <button onclick="editUser(${user.Id})" class="small-btn blue-btn">Güncelle</button>
          <button onclick="deleteUser(${user.Id})" class="small-btn red-btn">Sil</button>
        </div>
      </div>
    `;
  });
}

// Yeni personel ekleme fonksiyonu
async function addUser() {
  const username = document.getElementById("newUser").value.trim();
  const password = document.getElementById("newPass").value.trim();

  if (!username || !password) {
    Swal.fire("Uyarı", "Kullanıcı adı ve şifre gir!", "warning");
    return;
  }

  const result = await window.api.addUser({
    username,
    password
  });

  if (!result.ok) {
    Swal.fire("Hata!", result.error, "error");
    return;
  }

  document.getElementById("newUser").value = "";
  document.getElementById("newPass").value = "";

  await load();
}

// Personel silme fonksiyonu
async function deleteUser(id) {
  const confirmResult = await Swal.fire({
    title: "Emin misiniz?",
    text: "Bu personeli silmek istediğine emin misin?",
    icon: "warning",
    showCancelButton: true,
    confirmButtonColor: "#3085d6",
    cancelButtonColor: "#d33",
    confirmButtonText: "Evet, sil",
    cancelButtonText: "İptal"
  });

  if (!confirmResult.isConfirmed) return;

  const result = await window.api.deleteUser(id);

  if (!result.ok && result.error) {
    Swal.fire("Hata!", result.error, "error");
    return;
  }

  await load();
}

// Personel bilgilerini güncelleme fonksiyonu
async function editUser(id) {
  const user = staffUsers.find(u => Number(u.Id) === Number(id));

  if (!user) {
    Swal.fire("Hata!", "Personel bulunamadı.", "error");
    return;
  }

  const { value: formValues } = await Swal.fire({
    title: "Personel Düzenle",
    html:
      `<input id="swal-input1" class="swal2-input" placeholder="Kullanıcı Adı" value="${user.Username}">` +
      `<input id="swal-input2" class="swal2-input" placeholder="Şifre" value="${user.Password}">`,
    focusConfirm: false,
    showCancelButton: true,
    confirmButtonText: "Kaydet",
    cancelButtonText: "İptal",
    preConfirm: () => {
      return [
        document.getElementById("swal-input1").value,
        document.getElementById("swal-input2").value
      ];
    }
  });

  if (!formValues) return;

  const [newUsername, newPassword] = formValues;

  if (!newUsername || !newPassword) {
    Swal.fire("Uyarı", "Kullanıcı adı ve şifre boş bırakılamaz.", "warning");
    return;
  }

  const result = await window.api.updateUser({
    id,
    username: newUsername.trim(),
    password: newPassword.trim()
  });

  if (!result.ok) {
    Swal.fire("Hata!", result.error, "error");
    return;
  }

  Swal.fire("Başarılı", "Personel bilgileri güncellendi.", "success");

  await load();
}

/* =========================
   PERSONEL ÖZET
========================= */

// Personel giriş yaptığında araçlar sayfasının üstünde görünen doluluk oranlarını hesaplar
function updateStaffDashboard(cars) {
  const total = cars.length;
  const empty = MAX_CAPACITY - total;
  const percent = Math.floor((total / MAX_CAPACITY) * 100);

  const staffTotalCars = document.getElementById("staffTotalCars");
  const staffEmptySlots = document.getElementById("staffEmptySlots");
  const staffOccupancy = document.getElementById("staffOccupancy");

  if (staffTotalCars) staffTotalCars.innerText = total;
  if (staffEmptySlots) staffEmptySlots.innerText = empty;
  if (staffOccupancy) staffOccupancy.innerText = "%" + percent;
}

/* =========================
   OTOPARK HARİTASI
========================= */

// A1-A20 arası park yerlerinin görsel ızgarasını çizer
function renderParkingGrid(cars) {
  const grid = document.getElementById("parkingGrid");
  if (!grid) return;

  grid.innerHTML = "";

  PARK_SLOTS.forEach(slot => {
    const car = cars.find(c => String(c.Park).toLowerCase() === slot.toLowerCase());

    const div = document.createElement("div");

    div.className = car ? "park-slot full" : "park-slot empty";

    div.innerHTML = `
      <strong>${slot}</strong>
      <span>${car ? car.Plate : "Boş"}</span>
    `;

    div.onclick = () => {
      if (car) {
        Swal.fire({
          title: "Araç Bilgileri",
          html: `
            <b>Park:</b> ${slot}<br>
            <b>Plaka:</b> ${car.Plate}<br>
            <b>Marka:</b> ${car.Brand || "-"}<br>
            <b>Model:</b> ${car.Model || "-"}<br>
            <b>Sahip:</b> ${car.Owner || "-"}<br>
            <b>Giriş:</b> ${formatDate(car.EntryTime)}
          `,
          icon: "info"
        });
      } else {
        Swal.fire("Bilgi", `${slot} boş`, "info");
      }
    };

    grid.appendChild(div);
  });
}

// Araç ekleme formunda, dolu olan park yerlerinin seçilmesini engeller
function updateParkSelectAvailability(cars) {
  const parkSelect = document.getElementById("park");
  if (!parkSelect) return;

  [...parkSelect.options].forEach(option => {
    if (!option.value) return;

    const isFull = cars.some(c => String(c.Park).toLowerCase() === option.value.toLowerCase());

    option.disabled = isFull;
    option.textContent = isFull ? `${option.value} - Dolu` : option.value;
  });
}

/* =========================
   TABLO VE ARAÇ ARAMA
========================= */

// Türkçe karakterleri sadeleştirerek aramayı daha sağlıklı yapar
function normalizeSearchText(value) {
  return String(value || "")
    .toLocaleLowerCase("tr-TR")
    .replace(/ı/g, "i")
    .replace(/ğ/g, "g")
    .replace(/ü/g, "u")
    .replace(/ş/g, "s")
    .replace(/ö/g, "o")
    .replace(/ç/g, "c")
    .trim();
}

function getFilteredCars(cars) {
  const searchInput = document.getElementById("carSearch");
  const query = normalizeSearchText(searchInput ? searchInput.value : "");

  if (!query) return cars;

  return cars.filter(car => {
    const searchableText = normalizeSearchText([
      car.Plate,
      car.Brand,
      car.Model,
      car.Owner,
      car.Park
    ].join(" "));

    return searchableText.includes(query);
  });
}

function updateCarSearchInfo(totalCount, filteredCount) {
  const searchInfo = document.getElementById("carSearchInfo");
  const searchInput = document.getElementById("carSearch");

  if (!searchInfo) return;

  const query = searchInput ? searchInput.value.trim() : "";

  if (!query) {
    searchInfo.innerText = totalCount === 0
      ? "İçeride aktif araç bulunmuyor."
      : `Tüm aktif araçlar listeleniyor. Toplam: ${totalCount}`;
    return;
  }

  searchInfo.innerText = `Arama sonucu: ${filteredCount} / ${totalCount} araç gösteriliyor.`;
}

function filterCarTable() {
  const filteredCars = getFilteredCars(activeCarsCache);
  loadTable(filteredCars);
  updateCarSearchInfo(activeCarsCache.length, filteredCars.length);
}

function clearCarSearch() {
  const searchInput = document.getElementById("carSearch");

  if (searchInput) {
    searchInput.value = "";
  }

  filterCarTable();
}

// İçerideki araçların listelendiği tabloyu doldurur
function loadTable(cars) {
  const carList = document.getElementById("carList");
  const searchInput = document.getElementById("carSearch");
  const hasSearch = searchInput && searchInput.value.trim();

  if (!carList) return;

  carList.innerHTML = "";

  if (cars.length === 0) {
    carList.innerHTML = `
      <tr>
        <td colspan="6" class="table-empty-cell">
          ${hasSearch ? "Aramaya uygun araç bulunamadı." : "İçeride araç bulunmuyor."}
        </td>
      </tr>
    `;
    return;
  }

  cars.forEach(car => {
    carList.innerHTML += `
      <tr>
        <td>${car.Plate || "-"}</td>
        <td>${car.Brand || "-"}</td>
        <td>${car.Model || "-"}</td>
        <td>${car.Owner || "-"}</td>
        <td>${car.Park || "-"}</td>
        <td>
          <button onclick="exitCar(${car.Id})">Çıkış</button>
        </td>
      </tr>
    `;
  });
}

/* =========================
   ARAÇ EKLE
========================= */

// Yeni bir aracın girişini yapar
async function addCar() {
  const plate = document.getElementById("plate").value.trim().toUpperCase();
  const brand = document.getElementById("brand").value.trim();
  const model = document.getElementById("model").value.trim();
  const owner = document.getElementById("owner").value.trim();
  const park = document.getElementById("park").value.trim();

  if (!plate || !brand || !model || !owner || !park) {
    Swal.fire("Uyarı", "Tüm alanları doldur!", "warning");
    return;
  }

  const cars = await window.api.getCars();

  if (cars.length >= MAX_CAPACITY) {
    Swal.fire("Uyarı", "Otopark dolu!", "warning");
    return;
  }

  const plateAlreadyExists = cars.some(car => normalizeSearchText(car.Plate) === normalizeSearchText(plate));

  if (plateAlreadyExists) {
    Swal.fire("Uyarı", "Bu plaka zaten içeride kayıtlı!", "warning");
    return;
  }

  const parkAlreadyFull = cars.some(car => String(car.Park).toLowerCase() === park.toLowerCase());

  if (parkAlreadyFull) {
    Swal.fire("Uyarı", "Bu park yeri dolu!", "warning");
    return;
  }

  await window.api.addCar({
    plate,
    brand,
    model,
    owner,
    park
  });

  document.getElementById("plate").value = "";
  document.getElementById("brand").value = "";
  document.getElementById("model").value = "";
  document.getElementById("owner").value = "";
  document.getElementById("park").value = "";

  load();
}

/* =========================
   ARAÇ ÇIKIŞ
========================= */

// Aracın otoparktan çıkışını sağlar ve ücret hesaplatır
async function exitCar(id) {
  const confirmResult = await Swal.fire({
    title: "Çıkış İşlemi",
    text: "Çıkışı onaylıyor musunuz?",
    icon: "question",
    showCancelButton: true,
    confirmButtonColor: "#3085d6",
    cancelButtonColor: "#d33",
    confirmButtonText: "Evet, onaylıyorum",
    cancelButtonText: "İptal"
  });

  if (!confirmResult.isConfirmed) {
    return;
  }

  const result = await window.api.exitCar(id);

  if (!result.ok && result.error) {
    Swal.fire("Hata!", result.error, "error");
    return;
  }

  Swal.fire({
    title: "Çıkış Başarılı",
    html: `Süre: ${result.hours} saat<br>Ücret: ${result.fee} TL`,
    icon: "success"
  });

  load();
}

/* =========================
   TARİH / SAAT YARDIMCI FONKSİYONLARI
========================= */

// Gelen tarih değerini güvenli şekilde Date nesnesine çevirir
function parseDateSafe(value) {
  if (!value) return null;

  // SQL Server bazen "2026-05-17T03:10:00.000Z" gibi UTC gönderir.
  // Bazense "2026-05-17 03:10:00" gibi düz DATETIME gönderir.
  // Bu fonksiyon ikisini de güvenli okumaya çalışır.
  let date;

  if (value instanceof Date) {
    date = value;
  } else {
    const text = String(value).trim();

    if (!text) return null;

    // SQL'den "YYYY-MM-DD HH:mm:ss" gelirse Safari/Electron tarafında daha güvenli olsun diye T'ye çeviriyoruz.
    if (/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}/.test(text)) {
      date = new Date(text.replace(" ", "T"));
    } else {
      date = new Date(text);
    }
  }

  if (isNaN(date.getTime())) return null;

  return date;
}

// Tarih verilerini Türkiye saatine göre formatlar
function formatDate(value) {
  if (!value) return "-";

  let text = String(value).trim();

  // SQL Server'dan gelen format:
  // 2026-05-17 03:10:00
  // veya
  // 2026-05-17T03:10:00.000Z

  // Eğer sonunda Z varsa UTC olarak gelmiştir, Türkiye için +3 saat ekliyoruz
  if (text.endsWith("Z")) {
    const date = new Date(text);
    date.setHours(date.getHours() + 3);

    return formatDateManual(date);
  }

  // Eğer SQL formatı "YYYY-MM-DD HH:mm:ss" şeklindeyse parçalayarak basıyoruz
  const cleanText = text.replace("T", " ").split(".")[0];
  const parts = cleanText.split(" ");

  if (parts.length >= 2) {
    const datePart = parts[0];
    const timePart = parts[1];

    const [year, month, day] = datePart.split("-");
    const [hour, minute] = timePart.split(":");

    if (year && month && day && hour && minute) {
      return `${day}.${month}.${year} ${hour}:${minute}`;
    }
  }

  const date = new Date(value);

  if (isNaN(date.getTime())) return "-";

  return formatDateManual(date);
}

function formatDateManual(date) {
  const day = String(date.getDate()).padStart(2, "0");
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const year = date.getFullYear();

  const hour = String(date.getHours()).padStart(2, "0");
  const minute = String(date.getMinutes()).padStart(2, "0");

  return `${day}.${month}.${year} ${hour}:${minute}`;
}

/* =========================
   ROL KONTROL
========================= */

// Kullanıcı admin değilse yani personelse yetkisiz sayfaları gizler
function applyRole() {
  if (role === "staff") {
    const dashboardBtn = document.getElementById("dashboardBtn");
    if (dashboardBtn) dashboardBtn.style.display = "none";

    showPage("cars");
  } else {
    showPage("dashboard");
  }
}

/* =========================
   OTOMATİK PLAKA TANIMA
========================= */

async function openPlateReader() {
  const serverAddress = await window.api.getServerAddress();

  await Swal.fire({
    title: "Plaka Okuyucu",
    html: `
      <p style="color: #cbd5e1; margin-bottom: 20px;">
        Aşağıdaki QR kodu <b>telefonunuzun kamerasıyla</b> okutarak anında fotoğraf çekebilirsiniz!<br>
        Veya bilgisayarınızdan dosya seçebilirsiniz.
      </p>

      <div id="qrcode" style="display: flex; justify-content: center; margin-bottom: 20px; padding: 15px; background: white; border-radius: 12px; width: max-content; margin-left: auto; margin-right: auto;"></div>
      
      <p style="color: #60a5fa; font-size: 14px; margin-bottom: 15px;">Bağlantı Adresi: ${serverAddress}</p>

      <input type="file" id="plateImageFile" accept="image/*" style="display:none;" onchange="handlePlateImageUpload(event)">
      <div style="display: flex; gap: 10px; justify-content: center;">
        <button onclick="document.getElementById('plateImageFile').click()" class="primary-btn" style="padding: 0 20px; font-size: 16px;">
          📁 Bilgisayardan Seç
        </button>
      </div>

      <div id="platePreviewContainer" style="margin-top: 20px; display: none;">
        <img id="platePreview" style="max-width: 100%; border-radius: 12px; border: 2px dashed #3b82f6;" />
        <p id="plateStatus" style="color: #60a5fa; margin-top: 10px; font-weight: bold;">Görüntü işleniyor, lütfen bekleyin... ⏳</p>
      </div>
    `,
    didOpen: () => {
      new QRCode(document.getElementById("qrcode"), {
        text: serverAddress,
        width: 180,
        height: 180,
        colorDark: "#000000",
        colorLight: "#ffffff",
        correctLevel: QRCode.CorrectLevel.H
      });
    },
    showConfirmButton: false,
    showCancelButton: true,
    cancelButtonText: "Kapat",
    background: "#1e293b",
    color: "#fff",
    width: 600
  });
}

async function handlePlateImageUpload(event) {
  const file = event.target.files[0];
  if (!file) return;

  await processPlateImage(file);
}

// Telefondan fotoğraf geldiğinde bu kanal tetiklenir
window.api.onMobileImageReceived(async (base64) => {
  const previewContainer = document.getElementById("platePreviewContainer");

  if (previewContainer) {
    await processPlateImage(base64);
  } else {
    await openPlateReader();
    await processPlateImage(base64);
  }
});

async function processPlateImage(imageSource) {
  const preview = document.getElementById("platePreview");
  const container = document.getElementById("platePreviewContainer");
  const status = document.getElementById("plateStatus");

  if (!preview || !container || !status) return;

  if (typeof imageSource === "string" && imageSource.startsWith("data:image")) {
    preview.src = imageSource;
  } else if (imageSource instanceof File) {
    preview.src = URL.createObjectURL(imageSource);
  }

  container.style.display = "block";
  status.innerHTML = "Plaka yapay zeka ile okunuyor, lütfen bekleyin... ⏳";

  try {
    let base64Image = "";

    if (typeof imageSource === "string" && imageSource.startsWith("data:image")) {
      base64Image = imageSource;
    } else if (imageSource instanceof File) {
      base64Image = await new Promise((resolve, reject) => {
        const img = new Image();

        img.onload = () => {
          const canvas = document.createElement("canvas");

          let width = img.width;
          let height = img.height;
          const maxSize = 1200;

          if (width > height) {
            if (width > maxSize) {
              height *= maxSize / width;
              width = maxSize;
            }
          } else {
            if (height > maxSize) {
              width *= maxSize / height;
              height = maxSize;
            }
          }

          canvas.width = width;
          canvas.height = height;

          const ctx = canvas.getContext("2d");
          ctx.drawImage(img, 0, 0, width, height);

          resolve(canvas.toDataURL("image/jpeg", 0.8));
        };

        img.onerror = () => reject(new Error("Resim okunamadı"));
        img.src = URL.createObjectURL(imageSource);
      });
    }

    const formData = new FormData();
    formData.append("base64Image", base64Image);
    formData.append("language", "tur");
    formData.append("apikey", "helloworld");
    formData.append("OCREngine", "2");
    formData.append("scale", "true");

    const response = await fetch("https://api.ocr.space/parse/image", {
      method: "POST",
      body: formData
    });

    if (!response.ok) {
      throw new Error(`Yapay zeka sunucusu şu an meşgul veya resim çok büyük. Kod: ${response.status}`);
    }

    const result = await response.json();

    if (result.IsErroredOnProcessing) {
      throw new Error("Yapay Zeka API Hatası: " + (result.ErrorMessage[0] || "Bilinmiyor"));
    }

    let rawText = "";

    if (result.ParsedResults && result.ParsedResults.length > 0) {
      rawText = result.ParsedResults[0].ParsedText;
    }

    const finalPlate = aiPlateFixer(rawText);

    if (finalPlate) {
      status.innerHTML = `<span style="color: #22c55e;">Yapay Zeka Onayladı! Plaka: ${finalPlate}</span>`;
      document.getElementById("plate").value = finalPlate;

      setTimeout(() => {
        Swal.close();
      }, 2000);
    } else {
      let cleanedText = rawText.toUpperCase().replace(/[^A-Z0-9]/g, "");
      cleanedText = cleanedText.replace(/^(TR|TC)/, "").replace(/(TR)$/, "");

      if (cleanedText.length >= 4) {
        status.innerHTML = `<span style="color: #f59e0b;">Uyarı: Yapay Zeka formatı doğrulayamadı. Okunan: ${cleanedText}</span>`;
        document.getElementById("plate").value = cleanedText;
      } else {
        status.innerHTML = `<span style="color: #f87171;">Plaka bulunamadı. Lütfen daha net bir fotoğraf çekin.</span>`;
      }
    }

  } catch (err) {
    status.innerHTML = `<span style="color: #f87171;">Bir hata oluştu: ${err.message}</span>`;
  }
}

// Yapay Zeka Tabanlı Plaka Format Düzeltici
function aiPlateFixer(rawText) {
  let t = String(rawText || "").toUpperCase().replace(/[^A-Z0-9]/g, "");

  t = t.replace(/^(TR|TC)/, "").replace(/(TR)$/, "");

  const numMap = {
    "O": "0",
    "Q": "0",
    "D": "0",
    "I": "1",
    "L": "1",
    "Z": "2",
    "S": "5",
    "B": "8",
    "G": "6"
  };

  const charMap = {
    "0": "O",
    "1": "I",
    "2": "Z",
    "5": "S",
    "8": "B",
    "6": "G"
  };

  if (t.length < 5 || t.length > 9) return null;

  let p1 = t.substring(0, 2);
  let p1Fixed = p1.split("").map(c => numMap[c] || c).join("");

  let remaining = t.substring(2);

  for (let letterLen = 1; letterLen <= 3; letterLen++) {
    let lettersPart = remaining.substring(0, letterLen);
    let numbersPart = remaining.substring(letterLen);

    if (numbersPart.length < 2 || numbersPart.length > 4) continue;

    let lettersFixed = lettersPart.split("").map(c => charMap[c] || c).join("");
    let numbersFixed = numbersPart.split("").map(c => numMap[c] || c).join("");

    let combined = p1Fixed + lettersFixed + numbersFixed;

    if (/(0[1-9]|[1-7][0-9]|8[0-1])[A-Z]{1,3}[0-9]{2,4}/.test(combined)) {
      return `${p1Fixed} ${lettersFixed} ${numbersFixed}`;
    }
  }

  return null;
}

/* =========================
   MARKA & MODEL OTOMATİK TAMAMLAMA
========================= */

const carDatabase = {
  "Audi": ["A3", "A4", "A5", "A6", "Q3", "Q5", "Q7"],
  "BMW": ["1 Serisi", "3 Serisi", "4 Serisi", "5 Serisi", "X1", "X3", "X5"],
  "Citroen": ["C3", "C4", "C5 Aircross", "Berlingo", "Ami"],
  "Dacia": ["Duster", "Sandero", "Logan", "Lodgy", "Spring"],
  "Fiat": ["Egea", "Fiorino", "Doblo", "Panda", "500", "Linea"],
  "Ford": ["Focus", "Fiesta", "Courier", "Puma", "Kuga", "Transit"],
  "Honda": ["Civic", "City", "Accord", "CR-V", "HR-V"],
  "Hyundai": ["i20", "Tucson", "Bayon", "Elantra", "i10", "Kona"],
  "Kia": ["Sportage", "Rio", "Stonic", "Ceed", "Picanto"],
  "Mercedes-Benz": ["A Serisi", "C Serisi", "E Serisi", "GLA", "GLC", "Vito"],
  "Nissan": ["Qashqai", "Juke", "X-Trail", "Micra"],
  "Opel": ["Corsa", "Astra", "Crossland", "Mokka", "Insignia", "Combo"],
  "Peugeot": ["208", "2008", "308", "3008", "408", "5008", "Rifter"],
  "Renault": ["Clio", "Megane", "Tailant", "Captur", "Austral", "Symbol", "Kangoo"],
  "Seat": ["Leon", "Ibiza", "Arona", "Ateca"],
  "Skoda": ["Octavia", "Superb", "Scala", "Kamiq", "Karoq"],
  "Togg": ["T10X"],
  "Toyota": ["Corolla", "Yaris", "C-HR", "RAV4", "Hilux", "Proace"],
  "Volkswagen": ["Polo", "Golf", "Passat", "Tiguan", "T-Roc", "Caddy", "Transporter"],
  "Volvo": ["S60", "S90", "XC40", "XC60", "XC90"]
};

function initCarDatabase() {
  const brandList = document.getElementById("brandList");

  if (!brandList) return;

  brandList.innerHTML = "";

  for (let brand in carDatabase) {
    let option = document.createElement("option");
    option.value = brand;
    brandList.appendChild(option);
  }
}

// Marka giriş kutusuna yazıldıkça Model listesini dinamik olarak filtreler ve günceller
window.updateModelList = function () {
  const brandInput = document.getElementById("brand");
  const modelList = document.getElementById("modelList");

  if (!brandInput || !modelList) return;

  const brand = brandInput.value;

  modelList.innerHTML = "";

  let matchedBrand = Object.keys(carDatabase).find(
    b => b.toLowerCase() === brand.toLowerCase()
  );

  if (matchedBrand) {
    carDatabase[matchedBrand].forEach(model => {
      let option = document.createElement("option");
      option.value = model;
      modelList.appendChild(option);
    });
  }
};

/* =========================
   BAŞLANGIÇ
========================= */

loadParkOptions();
applyRole();
initCarDatabase();