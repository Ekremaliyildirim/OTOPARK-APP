const sql = require("mssql");

// Veritabanı bağlantı ayarları
const config = {
  user: "sa", // Veritabanı kullanıcı adı
  password: "1234", // Veritabanı şifresi
  server: "localhost", // Veritabanı sunucusu
  port: 1433, // SQL Server varsayılan portu
  database: "OtoparkDB", // Kullanılacak veritabanı adı
  options: {
    encrypt: false, // Yerel ağda genelde false kullanılır
    trustServerCertificate: true // Sertifika doğrulamasını atlamak için
  },
  pool: {
    max: 10, // Aynı anda maksimum açık bağlantı sayısı
    min: 0,
    idleTimeoutMillis: 30000 // Boşta kalan bağlantının kapanma süresi
  },
  connectionTimeout: 30000,
  requestTimeout: 30000
};

// SQL sorgularını çalıştıran asenkron fonksiyon
async function query(q) {
  try {
    // Veritabanına bağlan
    const pool = await sql.connect(config);
    // Gelen sorguyu çalıştır (q parametresi)
    const result = await pool.request().query(q);
    // Kayıtları döndür, eğer kayıt yoksa boş dizi döndür
    return result.recordset || [];
  } catch (err) {
    console.error("DB HATA:", err);
    throw err; // Hatayı yukarıya fırlat
  }
}

// Başka dosyalarda kullanabilmek için query fonksiyonunu dışa aktar
module.exports = { query };